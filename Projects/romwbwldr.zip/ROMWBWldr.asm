;extract from ZRCC monitor
;ROMWBW loader
;located in memory 0x5000 where ROMWBW is blank
; an extended Intel Hex loader that skips over location 0x5xxx

UARTconf 	equ 10h		; UART configuration register
RxData  	equ 16h        	; on-chip UART receive register
TxData  	equ 18h        	; on-chip UART transmit register
RxStat  	equ 14h        	; on-chip UART transmitter status/control register
TxStat  	equ 12h        	; 0n-chip UART receiver status/control register

CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

MMUctrl	equ 0f0h		; MMU master control reg
MMUptr	equ 0f1h		; MMU page descriptor reg pointer
MMUsel	equ 0f5h		; MMU descriptor select port
MMUmove	equ 0f4h		; MMU block move port
MMUinv	equ 0f2h		; MMU invalidation port
DMActrl	equ 01fh		; DMA master control reg
DMA2dstL	equ 10h		; DMA chan 2 destination reg low
DMA2dstH	equ 11h		; DMA chan 2 destination reg high
DMA2srcL	equ 12h		; DMA chan 2 source reg low
DMA2srcH	equ 13h		; DMA chan 2 source reg high
DMA2cnt	equ 14h		; DMA chan 2 count reg
DMA2td	equ 15h		; DMA chan 2 transaction descriptor
DMA3dstL	equ 18h		; DMA chan 3 destination reg low
DMA3dstH	equ 19h		; DMA chan 3 destination reg high
DMA3srcL	equ 1ah		; DMA chan 3 source reg low
DMA3srcH	equ 1bh		; DMA chan 3 source reg high
DMA3cnt	equ 1ch		; DMA chan 3 count reg
DMA3td	equ 1dh		; DMA chan 3 transaction descriptor

	org 05000h
	jp start		;boot table
testseed: ds 2		; RAM test seed value
addr3116	ds 2		; high address for Intel Hex format 4
RDsector	ds 1		; current RAM disk sector
RDtrack	ds 1		; current RAM disk track 
RDaddr	ds 2		; current RAM disk address 
sectoff	ds 2		; offset from a track & sector
readbsysav	ds 1	;scratch memory for readbsy routine
RdBsyDiag	ds 4		;diagnostic

start:
	ld sp,05f00h	; initialize stack in 0x5xxx

;configure UART 
	call UARTPage	;point I/O page to UART
    	ld hl,signon$
        	call strout

;Main command loop
CMD:  	

CMDLP1:
        	CALL cinq
	cp ':'		; Is this Intel load file?
	jp z,initload
	jr CMDLP1

; initialize for file load operation
initload:
	ld hl,0		; clear the high address in preparation for file load
	ld (addr3116),hl	; addr3116 modified with Intel Hex format 4 
; load Intel file
fileload:
	call GETHEXQ	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a		; save byte count to reg D
	ld c,a		; save copy of byte count to reg C
	ld b,a		; initialize the checksum
	call GETHEXQ	; get MSB of address
	ld h,a		; HL points to memory to be loaded
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get LSB of address
	ld l,a
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the record type, 0 is data, 1 is end
	cp 0
	jp z,filesave
	cp 1		; end of file transfer?
	jp z,fileend
	cp 4		; Extended linear address?
	jp nz,unknown	; if not, print a 'U'
; Extended linear address for greater than 64K
; this is where addr3116 is modified
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,d		; byte count should always be 2
	cp 2
	jp nz,unknown
	call GETHEXQ	; get first byte (MSB) of high address
	ld (addr3116+1),a	; save to addr3116+1
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
; Little Endian format.  MSB in addr3116+1, LSB in addr3116
	call GETHEXQ	; get the 2nd byte (LSB) of of high address
	ld (addr3116),a	; save to addr3116
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
	ld a,'E'		; denote a successful Extended linear addr update
	jp filesav2
; end of the file load
fileend:
	call GETHEXQ	; flush the line, get the last byte
	ld hl,fileEnd$	;mark end of file with 'X'
	call strout
	call ZeroPage	;set I/O page to zero
	jp 0		;jump to execute ROMWBW
; the assumption is the data is good and will be saved to the destination memory
filesave:
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld ix,06000h	; 06000h is buffer for incoming data
filesavx:
	call GETHEXQ	; get a byte
	ld (ix),a		; save to buffer
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	inc ix
	dec d
	jp nz,filesavx
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
;check whether hl is 0x5xxx or 0x6xxx.  If so skip the DMA transfer


	call DMAPage	; set page i/o reg to DMA
; use DMA to put data from buffer to location pointed by ehl
	push hl		; destination RAM in hl, save it for now
	ld b,0		; clear out MSB of reg BC, reg C contains the saved byte count
	push bc		; DMA count is in reg BC, save it 
; set up DMA master control
	ld c,DMActrl	; set up DMA master control
	ld hl,0f0e0h	; software ready for dma0&1, no end-of-process, no links
;	outw (c),hl	; write DMA master control reg
	db 0edh,0bfh	; op code for OUTW (C),HL
; set up DMA count register 
	ld c,DMA3cnt	; setup count of 128 byte
	pop hl		; transfer what was saved in bc into hl
;	outw (c),hl	; write DMA3 count reg
	db 0edh,0bfh	; op code for OUTW (C),HL
; source buffer starts at 0x06000  <- remember this is the physical address of RAM 
	ld c,DMA3srcH	; source is 0x6000
	ld hl,06fh		; A23..A12 are 0x006		
;	outw (c),hl	; write DMA3 source high reg
	db 0edh,0bfh	; op code for OUTW (C),HL
	ld c,DMA3srcL	;
	ld hl,0f000h	; A11..A0 are 0x0
;	outw (c),hl	; write DMA3 source low reg
	db 0edh,0bfh	; op code for OUTW (C),HL	
; destination buffer is in e + hl (saved in stack right now)
	ld c,DMA3dstH
	ld a,(addr3116)	; get A23..A16 value into reg H
;no need for next instruction, RAM is at 0x0
	ld h,a		; 	
	pop de		; restore saved hl into de

	ld l,d		; move A15..A8 value
	ld a,0fh		; force lowest nibble of DMA3dstH to 0xF
	or l
do_dma3hi:
;	outw (c),hl	; write DMA3 destination high reg
	db 0edh,0bfh	; op code for OUTW (C),HL
	ld c,DMA3dstL
	ld h,d		; reg DE contain A15..A0 value
	ld l,e
	ld a,0f0h		; force highest nibble of DMA3dstL to 0xF
	or h
;	outw (c),hl	; write DMA3 destination low reg
	db 0edh,0bfh	; op code for OUTW (C),HL
; write DMA3 transaction description reg and start DMA
	ld hl,8080h	; enable DMA3, burst, byte size, flowthrough, no interrupt
;			;  incrementing memory for source & destination
	ld c,DMA3td	; setup DMA3 transaction descriptor reg
;	outw (c),hl	; write DMA3 transaction description reg
	db 0edh,0bfh	; op code for OUTW (C),HL
;  DMA should start now
	call UARTPage	; set page i/o reg to default
bypass:
	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr flushln	; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
flushln:
	call cinq		; keep on reading until ':' is encountered
	cp ':'
	jr nz,flushln
	jp fileload


; get hex without echo back
GETHEXQ:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET


;ASCHEX, convert ASCII to low nibble
;return Z flag set if not 0-9, A-F
; original value in regA returned if not hexdecimal character
ASCHEX: 	
	sub 30h		;ascii 0 is 0x30
	jp m,invalidx
	cp 0ah		;0-9?
	ret m
	sub 11h		;ascii A is 0x41
	jp m,invalidy
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;A-F?
	ret m
	sub 2ah		;ascii a is 0x61
	jp m,invalidz
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;a-f?
	ret m
invalidz
	add 20h-0ah	;return reg A to original value
invalidy
	add 11h
invalidx
	add 30h
	cp a		;set Z flag
	ret		;return with original regA and Z flag set

;send null-terminated string to console
strout: 	
	
	ld a,(hl)
	or a
	ret z
	call cout
	inc hl
	jr strout

; init page i/o reg to point to UART
UARTPage:
	push hl		; save register
	ld l,0feh		; set I/O page register to 0xFE
	jp setpage
; initialize Z280 page i/o reg to point to MMU and DMA
DMAPage:
MMUPage:
	push hl		; save register
	ld l,0ffh		; MMU and DMA page I/O reg is 0xFF
	jp setpage
; init page i/o reg to point to compactflash
ZeroPage:
CFPage:
	push hl		; save register
	ld l,0		; set I/O page register to 0

setpage:
	push bc		; save more reg
	ld c,08h		; reg c points to I/O page register
; reg L is already pre-loaded with correct page value
	db 0edh,6eh	; this is the op code for LDCTL (C),HL
	pop bc		; restore reg
	pop hl
	ret

;Get a char from the console and echo
cin:    
        	IN A,(RxStat)	; read on-chip UART receive status
        	AND 10H				;;Z data available?
        	JP Z,cin
        	IN A,(RxData)	; save to reg A
        	OUT (TxData),A	; echo back
        	RET
; get char from console without echo
cinq:
        	IN A,(RxStat)	; read on-chip UART receive status
        	AND 10H				;;Z data available?
        	JP Z,cinq
        	IN A,(RxData)	; save to reg A
        	RET

cout:
;Output a character in regA to the console   
	push af		; save data to be printed to stack
cout1:  	IN A,(TxStat)	; transmit empty?
        	rra
        	jp nc,cout1
	pop af		; restore data to be printed
        	OUT (TxData),A	; write it out
        	RET

;MMUtbl	ds 32		; 16 pages of system MMU page descriptors
MMUtbl	db 0ah,0,1ah,0,2ah,0,3ah,0,4ah,0,5ah,0,6ah,0,7ah,0
	db 8ah,0,9ah,0,0aah,0,0bah,0,0cah,0,0dah,0,0eah,0,0fah,0

;PROGEND:	equ $		; end of the program
PROGEND:	equ 0c000h		; end of the program is above the stack

;	org 0b000h		;put constants in 0xb000
signon$:	db 10,13," ROMWBW Loader", 13,10
	db " Ready to accept ROMWBW hex file",13,10
	db " Jump to location 0x0 when file load completed",13,10,0 

fileEnd$	db "X"
CRLF$	db 13,10,0

	END


