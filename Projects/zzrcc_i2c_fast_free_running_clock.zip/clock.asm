;12/17/20
;port clock routine from Z280RC
;the I2C register is now 0x9E
;SCL is D[1], SDA is D[0]
; translation from Z280RC register:
; 0x85 is now 3 on ZZRCC
; 0x84 is now 1 on ZZRCC
; 0x5 is now 2 on ZZRCC
; 0x4 is now 0 on ZZRCC
	ld a,0
I2C	equ 09eh		;bit bang I/O address of I2C
CCenter	equ 12352		;center of the clock face

	org 1000h
	jp start
error	db 0
pSec:	dw second_hand		;point to tip position of second in table
pMin:	dw minute_hand		;point to tip position of minute in table
pHour:	dw hour_hand		;point to tip position of hour in table
speedup:	dw 090f0h			;diag increase speed of display
init:				;initial data, organized as line + pixel offset 
;1 dot per hour
	dw 8512,9039,10458,12382,14298,15695,16192,15665,14246,12322,10406,9009
;3 pixels around center
	dw 11968,12098,12355,12610,12736,12606,12349,12094
;center is 12352
	dw 12352
initend:
;end of initialization data
second_hand:
;data point every 6 degrees (second), second_hand is 28,27,26 pixels long
	dw 8768,8896,9024,9792,10688
	dw 8771,8899,9027,9794,10689
	dw 8902,9030,9157,9796,10691
	dw 8905,9032,9160,9926,10820
	dw 9035,9163,9291,10056,10821
	dw 9294,9421,9421,10186,10950
	dw 9424,9552,9679,10316,10952
	dw 9683,9810,9937,10445,11081
	dw 9941,10068,10195,10703,11210
	dw 10327,10326,10453,10832,11339
	dw 10584,10583,10711,11089,11467
	dw 10970,10969,10968,11346,11724
	dw 11227,11354,11353,11603,11852
	dw 11611,11610,11737,11860,11981
	dw 11996,11995,11994,12116,12237
	dw 12380,12379,12378,12372,12365
	dw 12764,12763,12762,12628,12493
	dw 13147,13146,13017,12884,12749
	dw 13531,13402,13401,13139,12876
	dw 13786,13785,13784,13394,13004
	dw 14168,14039,14039,13649,13131
	dw 14423,14422,14293,13904,13387
	dw 14805,14676,14547,14031,13514
	dw 15059,14930,14801,14285,13641
	dw 15312,15184,15055,14412,13768
	dw 15438,15310,15309,14538,13767
	dw 15691,15563,15435,14664,13893
	dw 15817,15688,15560,14790,13892
	dw 15814,15686,15557,14916,14019
	dw 15939,15811,15683,14914,14017
	dw 15936,15808,15680,14912,14016
	dw 15933,15805,15677,14910,14015
	dw 15802,15674,15547,14908,14013
	dw 15799,15672,15544,14778,13884
	dw 15669,15541,15413,14648,13883
	dw 15410,15283,15283,14518,13754
	dw 15280,15152,15025,14388,13752
	dw 15021,14894,14767,14259,13623
	dw 14763,14636,14509,14001,13494
	dw 14377,14378,14251,13872,13365
	dw 14120,14121,13993,13615,13237
	dw 13734,13735,13736,13358,12980
	dw 13477,13350,13351,13101,12852
	dw 13093,13094,12967,12844,12723
	dw 12708,12709,12710,12588,12467
	dw 12324,12325,12326,12332,12339
	dw 11940,11941,11942,12076,12211
	dw 11557,11558,11687,11820,11955
	dw 11173,11302,11303,11565,11828
	dw 10918,10919,10920,11310,11700
	dw 10536,10665,10665,11055,11573
	dw 10281,10282,10411,10800,11317
	dw 9899,10028,10157,10673,11190
	dw 9645,9774,9903,10419,11063
	dw 9392,9520,9649,10292,10936
	dw 9266,9394,9395,10166,10937
	dw 9013,9141,9269,10040,10811
	dw 8887,9016,9144,9914,10812
	dw 8890,9018,9147,9788,10685
	dw 8765,8893,9021,9790,10687
minute_hand:
;data point every 6 degree (1 minute), minute_hand is 24,23,21,19,17,13,8 pixels long
	dw 9280,9408,9664,9920,10176,10688,11328
	dw 9283,9410,9666,9922,10178,10689,11329
	dw 9413,9541,9668,9924,10180,10691,11330
	dw 9415,9543,9798,10054,10309,10820,11330
	dw 9546,9673,9929,10184,10311,10821,11459
	dw 9676,9803,10058,10313,10440,10950,11460
	dw 9934,9934,10188,10443,10570,10952,11589
	dw 10064,10191,10318,10573,10699,11081,11589
	dw 10322,10449,10576,10702,10957,11210,11718
	dw 10579,10579,10833,10959,11086,11339,11718
	dw 10837,10836,10962,11088,11215,11467,11847
	dw 11094,11221,11219,11345,11472,11724,11975
	dw 11479,11478,11604,11602,11728,11852,12104
	dw 11735,11734,11861,11859,11857,11981,12104
	dw 11992,12119,12117,12115,12113,12237,12232
	dw 12376,12375,12373,12371,12369,12365,12360
	dw 12760,12631,12629,12627,12625,12493,12488
	dw 13015,13014,12885,12883,12881,12749,12616
	dw 13271,13270,13140,13138,13008,12876,12616
	dw 13654,13525,13523,13393,13264,13004,12743
	dw 13909,13780,13650,13520,13391,13131,12871
	dw 14163,14163,13905,13775,13646,13387,12998
	dw 14418,14289,14160,14030,13773,13514,12998
	dw 14672,14543,14414,14157,14027,13641,13125
	dw 14798,14798,14540,14283,14154,13768,13125
	dw 15052,14924,14667,14410,14281,13767,13252
	dw 15178,15049,14793,14536,14407,13893,13251
	dw 15303,15175,14918,14662,14405,13892,13378
	dw 15301,15173,15044,14788,14532,14019,13378
	dw 15427,15298,15042,14786,14530,14017,13377
	dw 15424,15296,15040,14784,14528,14016,13376
	dw 15421,15294,15038,14782,14526,14015,13375
	dw 15291,15163,15036,14780,14524,14013,13374
	dw 15289,15161,14906,14650,14395,13884,13374
	dw 15158,15031,14775,14520,14393,13883,13245
	dw 15028,14901,14646,14391,14264,13754,13244
	dw 14770,14770,14516,14261,14134,13752,13115
	dw 14640,14513,14386,14131,14005,13623,13115
	dw 14382,14255,14128,14002,13747,13494,12986
	dw 14125,14125,13871,13745,13618,13365,12986
	dw 13867,13868,13742,13616,13489,13237,12857
	dw 13610,13483,13485,13359,13232,12980,12729
	dw 13225,13226,13100,13102,12976,12852,12600
	dw 12969,12970,12843,12845,12847,12723,12600
	dw 12712,12585,12587,12589,12591,12467,12472
	dw 12328,12329,12331,12333,12335,12339,12344
	dw 11944,12073,12075,12077,12079,12211,12216
	dw 11689,11690,11819,11821,11823,11955,12088
	dw 11433,11434,11564,11566,11696,11828,12088
	dw 11050,11179,11181,11311,11440,11700,11961
	dw 10795,10924,11054,11184,11313,11573,11833
	dw 10541,10541,10799,10929,11058,11317,11706
	dw 10286,10415,10544,10674,10931,11190,11706
	dw 10032,10161,10290,10547,10677,11063,11579
	dw 9906,9906,10164,10421,10550,10936,11579
	dw 9652,9780,10037,10294,10423,10937,11452
	dw 9526,9655,9911,10168,10297,10811,11453
	dw 9401,9529,9786,10042,10299,10812,11326
	dw 9403,9531,9660,9916,10172,10685,11326
	dw 9277,9406,9662,9918,10174,10687,11327
	dw 9280,9408,9664,9920,10176,10688,11328
	dw 9280,9408,9664,9920,10176,10688,11328
hour_hand:
;data point every 6 degree (12 minutes), hour_hand is 16 pixels long
	dw 10304,10432,10560,10816,11072,11456
	dw 10306,10434,10561,10817,11073,11457
	dw 10307,10435,10563,10818,11074,11457
	dw 10437,10565,10692,10948,11075,11458
	dw 10439,10566,10694,10949,11204,11587
	dw 10568,10695,10823,11078,11205,11587
	dw 10697,10825,10952,11079,11334,11588
	dw 10827,10954,11081,11208,11463,11717
	dw 10956,11083,11210,11337,11463,11717
	dw 11213,11212,11339,11466,11592,11846
	dw 11342,11341,11468,11594,11721,11846
	dw 11471,11598,11597,11723,11849,11974
	dw 11727,11726,11853,11851,11978,12103
	dw 11984,11983,11982,12108,12106,12231
	dw 12112,12111,12238,12236,12234,12231
	dw 12368,12367,12366,12364,12362,12359
	dw 12624,12623,12494,12492,12490,12487
	dw 12752,12751,12750,12620,12618,12487
	dw 13007,13006,12877,12875,12746,12615
	dw 13263,13134,13133,13003,12873,12742
	dw 13390,13261,13260,13130,13001,12742
	dw 13517,13516,13387,13258,13128,12870
	dw 13772,13643,13514,13385,13255,12997
	dw 13899,13770,13641,13512,13255,12997
	dw 14025,13897,13768,13639,13382,13124
	dw 14152,14024,13895,13638,13509,13124
	dw 14279,14150,14022,13765,13508,13123
	dw 14277,14149,14020,13764,13635,13250
	dw 14403,14275,14147,13890,13634,13249
	dw 14402,14274,14145,13889,13633,13249
	dw 14400,14272,14144,13888,13632,13248
	dw 14398,14270,14143,13887,13631,13247
	dw 14397,14269,14141,13886,13630,13247
	dw 14267,14139,14012,13756,13629,13246
	dw 14265,14138,14010,13755,13500,13117
	dw 14136,14009,13881,13626,13499,13117
	dw 14007,13879,13752,13625,13370,13116
	dw 13877,13750,13623,13496,13241,12987
	dw 13748,13621,13494,13367,13241,12987
	dw 13491,13492,13365,13238,13112,12858
	dw 13362,13363,13236,13110,12983,12858
	dw 13233,13106,13107,12981,12855,12730
	dw 12977,12978,12851,12853,12726,12601
	dw 12720,12721,12722,12596,12598,12473
	dw 12592,12593,12466,12468,12470,12473
	dw 12336,12337,12338,12340,12342,12345
	dw 12080,12081,12210,12212,12214,12217
	dw 11952,11953,11954,12084,12086,12217
	dw 11697,11698,11827,11829,11958,12089
	dw 11441,11570,11571,11701,11831,11962
	dw 11314,11443,11444,11574,11703,11962
	dw 11187,11188,11317,11446,11576,11834
	dw 10932,11061,11190,11319,11449,11707
	dw 10805,10934,11063,11192,11449,11707
	dw 10679,10807,10936,11065,11322,11580
	dw 10552,10680,10809,11066,11195,11580
	dw 10425,10554,10682,10939,11196,11581
	dw 10427,10555,10684,10940,11069,11454
	dw 10301,10429,10557,10813,11070,11455
	dw 10302,10430,10559,10815,11071,11455

start:
	di
	ld sp,stack
	ld c,8h		;point to I/O page reg
	ld l,0		;I/O page 0 is where bit bang register located
	db 0edh,6eh	;op code for LDCTL (C),HL
	ld hl,error		;clear the error flag
	xor a
	ld (hl),a
;;;;;;;;;;;;;;;RTC routines;;;;;;;;;;;;;;;;;;;;;
;enable RTC

	call initOLED		;initialize the SSD1306
	call clearOLED		;clear the array memory
; set initial condition
	ld bc,initend-init		;size of the initialization table
	ld hl,init		;point to initialization data
initloop
	ld a,1
	ld e,(hl)			;get the LSB
	inc hl
	ld d,(hl)			;get the MSB
	inc hl
	ld (de),a			;initialize the pixel
	dec bc
	dec bc			;decrement bc twice per pass
	ld a,b
	or c
	jr nz,initloop

	call wOLED		;write out the inialized data
	call delay

clock:
;increment the second counter
;write data to OLED
;B is second, C is minute, D is hour
;Minute is increment at 30 second mark
;Hour is incremented every 12 minutes
;start from 0 hour, 0 minute, 0 second
	ld d,0
	ld b,d
	ld c,d
	ld e,1	;diag speedup factor
	ld hl,hour_hand
	ld (pHour),hl
	ld hl,minute_hand
	ld (pMin),hl
	ld hl,second_hand
	ld (pSec),hl
	jr clock1
rstHour:
	ld d,0	;clear hour counts
	ld hl,hour_hand
	ld (pHour),hl
;	call dLineHour	;draw hour hand
	jr clock1
rstMin:
	ld hl,minute_hand
	ld (pMin),hl
	ld c,0
	inc d
	ld a,d
	cp 12		;reset hour
	jr z,rstHour
	jr clock1
rstSec:
	ld hl,second_hand
	ld (pSec),hl
	ld b,0
	inc c
	ld a,c
	cp 12		;update hour at 12,24,36,48,59 minutes
	jr z,updHour
	cp 24
	jr z,updHour
	cp 36
	jr z,updHour
	cp 48
	jr z,updHour
	cp 59
	jr z,updHour
	cp 60
	jr z,rstMin
clock1:
	ld a,1
	call tip_position
	dec e		;diag, do wOLED not very often
	call wOLED
	call delay
;erase current position
	xor a
	call tip_position
;update tip position
	inc b
	ld a,b
	cp 30		;update minute at 30 second mark
	jr z,updMin	
	cp 60		;reset second to zero if 60
	jr z,rstSec
xxxx:
	ld hl,(pSec)	
	inc hl		;point to next word of second_hand table
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	ld (pSec),hl
;this work because the table is lesser than 256 and started on 256-byte boundary
	jp clock1			;loop forever
updMin:
	ld hl,(pMin)
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl		;point to next word of minute_hand table
	ld (pMin),hl
;this work because the table is lesser than 256 and started on 256-byte boundary
	jr xxxx
updHour:
	ld hl,(pHour)
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl
	inc hl		;point to next word of hour_hand table
	ld (pHour),hl
;	call dLineHour	;draw hour hand
;this work because the table is lesser than 256 and started on 256-byte boundary
	jr clock1		;resume with second_hand=0


;;;;;;;;;;;;clock routine;;;;;;;;;;;;
tip_position:
;show or erase the tip of second/minute/hour
;regA =1 to show, regA=0 to erase
	push hl
	ld ix,(pSec)		;pSec points to entry in second_hand table
	ld l,(ix)
	ld h,(ix+1)		;3 pixel per second entry
	ld (hl),a
	ld l,(ix+2)
	ld h,(ix+3)
	ld (hl),a
	ld l,(ix+4)
	ld h,(ix+5)
	ld (hl),a
	ld l,(ix+6)
	ld h,(ix+7)
	ld (hl),a
	ld l,(ix+8)
	ld h,(ix+9)
	ld (hl),a

	ld ix,(pMin)	;4 pixel per minute entry
	ld l,(ix)
	ld h,(ix+1)
	ld (hl),a
	ld l,(ix+2)
	ld h,(ix+3)
	ld (hl),a
	ld l,(ix+4)
	ld h,(ix+5)
	ld (hl),a
	ld l,(ix+6)
	ld h,(ix+7)
	ld (hl),a
	ld l,(ix+8)
	ld h,(ix+9)
	ld (hl),a
	ld l,(ix+10)
	ld h,(ix+11)
	ld (hl),a
	ld l,(ix+12)
	ld h,(ix+13)
	ld (hl),a

	ld ix,(pHour)
	ld l,(ix)
	ld h,(ix+1)
	ld (hl),a
	ld l,(ix+2)
	ld h,(ix+3)
	ld (hl),a
	ld l,(ix+4)
	ld h,(ix+5)
	ld (hl),a
	ld l,(ix+6)
	ld h,(ix+7)
	ld (hl),a
	ld l,(ix+8)
	ld h,(ix+9)
	ld (hl),a
	ld l,(ix+10)
	ld h,(ix+11)
	ld (hl),a
	pop hl
	ret
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
delay:
	push bc
	push af
;	ld bc,1000h
	ld bc,(speedup)	;get delay factor from variable
	ld a,b		;is b=0?
	or a
	jr z,delay1
	dec a		;if not, decrement the delay factor
	ld (speedup+1),a
delay1:
	nop
	dec bc
	ld a,b
	or a		;cp 0
	jp nz,delay1
	pop af
	pop bc
	ret

clearOLED:
; clear array
	ld hl,array	;point to array
	ld e,32		;outer loop counter
	ld b,0		;inner loop is 256
	xor a
clrOLED1:
	ld (hl),a		;clear memory
	inc hl
	djnz clrOLED1
	dec e		;outer loop
	jp nz,clrOLED1
	ret

initOLED:
;;;;;;;;;;;;;;;;;;; Should be table driven ;;;;;;;;;;
	call i2cs		;start
	ld c,078h		;SSD1306 address
	call wi2c
	ld c,0aeh		;turn off display
	call wi2c
   	ld c,0d5h		;set display clock div
	call wi2c
	ld c,080h		;ratio 0x80
	call wi2c
	ld c,000h		;set multiplex
	call wi2c
	ld c,03fh		; 128x32
	call wi2c
	ld c,0d3h		;set display offset
	call wi2c
	ld c,000h		
	call wi2c		
	ld c,040h		;set startline
	call wi2c
	ld c,08dh		;charge pump
	call wi2c
	ld c,014h		;vccstate 14
	call wi2c
	ld c,020h		;memorymode
	call wi2c
	ld c,000h		
	call wi2c
;	ld c,0a1h		;a0 upside down segremap
;	call wi2c
;	ld c,0c8h		;com scan dec
;	call wi2c
	ld c,0dah		;set com pins
	call wi2c
	ld c,012h		; 02 128x32 12
	call wi2c
	ld c,081h		; set contrast
	call wi2c
	ld c,0ffh		;contrast
	call wi2c
	ld c,0d9h		;set precharge
	call wi2c
	ld c,0f1h		;vcc state f1
	call wi2c
	ld c,0dbh		;set vcom detect
	call wi2c
	ld c,040h
	call wi2c
	ld c,0a4h		;display all on resume
	call wi2c
	ld c,0a6h		;normal display
	call wi2c
	ld c,0afh		;display on
	call wi2c
	call i2cp
	ret

wOLED:
; write entire screen of data
; clumpsy-each data byte to the display is consists of 8 lines, with the msb bit the 8th line
;   and the lsb bit the first line.  So start with the 8th line, send off the bit on I2C, go back 128 pixels
;   and ship off the next bit, so on.
	ld a,(speedup+1)	;diag, check speedup parameter
	or a		;diag
	jr nz,noSpeedUp	;diag
	xor a		;diag 
	cp e		;diag
	ret nz		;diag
	ld e,7		;diag do this every 7 calls
noSpeedUp:
	push bc
	push de
	push hl
	call i2cs		;start
	ld c,078h		;SSD1306 address
	call wi2c
	ld c,40h		;data
	call wi2c
	ld e,8		;do 8 lines, each line is 8 pixels tall
	push de		;save line count
	ld hl,array	;point to screen data array
wwdatnxtl:
	ld c,128		;a line is 128 bytes
wwdatnxtb:
	ld b,8		;a byte is 8 pixels in vertical direction
	push hl		;save
	ld de,896
	add hl,de
	ld de,128
wwdat:
	xor a		;clear carry bit	
	ld a,(hl)		;get screen array at current location
	sbc hl,de		;pixel in vertical direction, -128 apart
	or a		;cp 0
	jp nz,wwdathi
;;;;;;;;;;;;;;;;;;;;;;;;;;
;	call bit0
;place bit0 routine inline
;ZZ	ld a,4
;ZZ SCL is D[1], SDA is D[0]
	ld a,0
	out (I2C),a	;change to 0 while clock low
;zz	inc a		;same as ld a,5
;ZZ SCL is D[1], SDA is D[0]
	ld a,2
	out (I2C),a	;clock high, data 0
;ZZ	dec a		;same as ld a,4
;ZZ SCL is D[1], SDA is D[0]
	ld a,0
;	out (I2C),a	;clock low, data 0
;;;;;;;;;;;;;;;;;;;;;;;;;;
	jp nxtpix
wwdathi:
;;;;;;;;;;;;;;;;;;;;;;;
;	call bit1
;place bit1 routine inline
;ZZ	ld a,84h
;ZZ SCL is D[1], SDA is D[0]
	ld a,1
	out (I2C),a	;change to 1 while clock low
;ZZ	ld a,085h
;ZZ SCL is D[1], SDA is D[0]
	ld a,3
	out (I2C),a	;clock high, data 1
;ZZ	ld a,84h
;ZZ SCL is D[1], SDA is D[0]
	ld a,1
;	out (I2C),a	;clock low, data 1
;;;;;;;;;;;;;;;;;
nxtpix:
	dec b
	out (I2C),a	;this won't change the conditional flags
	jp nz,wwdat
;	djnz wwdat	;do a byte of data
	call sAck		;done one byte of data, wait for slave acknowledge
	pop hl
	inc hl
	dec c
	jp nz,wwdatnxtb
;finish one line of 8-bit character, need to do 8 lines
;next line is 8x128 away
	ld de,896		;HL has reached the beginning of a new line at this point
	add hl,de
	pop de		;restore line count 
	dec e		;do 8 lines, each line is 8 pixels tall
          push de		;save it again
	jp nz,wwdatnxtl
	pop de		;clean up stack
	call i2cp		;STOP command, 
	pop hl
	pop de
	pop bc
	ret

i2cs:
; I2C START command
;Z280RC AD8 is clock (SCL), AD15 is data (SDA), and AD9 is RTC_enable, AD[10] is I2C_enable
;	ld a,085h
;ZZ SCL is D[1], SDA is D[0]
	ld a,3
	out (I2C),a	;set SCL and SDA high
	nop
	nop
	nop
	nop
	nop
	nop
;	ld a,5
;ZZ SCL is D[1], SDA is D[0]
	ld a,2
	out (I2C),a	;START
	nop
	nop
	nop
	nop
	nop
	nop
	nop
;	ld a,4
;ZZ SCL is D[1], SDA is D[0]
	ld a,0
	out (I2C),a	;clock low
	ret
i2cp:
;I2C STOP command
;	ld a,4		;clock low, data low
;ZZ SCL is D[1], SDA is D[0]
	ld a,0
	out (I2C),a
;	ld a,5		;clock high, data low
;ZZ SCL is D[1], SDA is D[0]
	ld a,2
	out (I2C),a
	nop
	nop
	nop
	nop
;	ld a,085h		;data goes high while clock high (STOP)
;ZZ SCL is D[1], SDA is D[0]
	ld a,3
	out (I2C),a
	ret

wi2c:
; write value in reg C to I2C bitbang register
	bit 7,c
	jr z,call70
	call bit1
	jr do6
call70:	call bit0
do6:	bit 6,c
	jr z,call60
	call bit1
	jr do5
call60:	call bit0
do5:	bit 5,c
	jr z,call50
	call bit1
	jr do4
call50:	call bit0
do4:	bit 4,c
	jr z,call40
	call bit1
	jr do3
call40:	call bit0
do3:	bit 3,c
	jr z,call30
	call bit1
	jr do2
call30:	call bit0
do2:	bit 2,c
	jr z,call20
	call bit1
	jr do1
call20:	call bit0
do1:	bit 1,c
	jr z,call10
	call bit1
	jr do0
call10:	call bit0
do0:	bit 0,c
	jr z,call00
	call bit1
	jp sAck		;slave acknowledge and return
call00:	call bit0
dosack:
	jp sAck		;slave acknowledge and return

sAck:	
;	ld a,84h		;wait for acknowledge
;ZZ SCL is D[1], SDA is D[0]
	ld a,1
	out (I2C),a
	nop
	nop
	nop
;	ld a,085h		;clock high with data high, expect slave to pull it low
;ZZ SCL is D[1], SDA is D[0]
	ld a,3
	out (I2C),a
;need to do word read because data are in high byte (D[15])
;	push hl
;	push bc
;	ld c,I2C
;	db 0edh,0b7h	;op code for INW HL,(C)
;	ld a,l		;D[15] is bit 7 of regL
;	pop bc
;	pop hl
;	and 80h		;expect it to be low for slave acknowledge

;ZZ SCL is D[1], SDA is D[0]
	in a,(I2C)
	and 1		;SDA is bit 0, expect it to be low for slave ack
	jp nz,errormsg

;	ld a,84h
;ZZ SCL is D[1], SDA is D[0]
	ld a,1
	out (I2C),a	;clock low with data high
	nop
	nop
	nop

	ret
errormsg:

	
;	ld a,4
;ZZ SCL is D[1], SDA is D[0]
	ld a,0
	out (I2C),a	;clock low, data low
	nop
	nop
	nop
	nop
	ld a,(error)
	or 80h
	ld (error),a	;set error flag
	nop
	nop
;ZZ SCL is D[1], SDA is D[0]
	ld a,2
	out (I2C),a
	nop
	nop
	nop
	nop
	nop
;	ld a,085h
;ZZ SCL is D[1], SDA is D[0]
	ld a,3
	out (I2C),a	;data low to high while clock high (STOP)

	jp 0b400h		;return to command prompt
bit0:
;	ld a,4
;ZZ SCL is D[1], SDA is D[0]
	ld a,0
	out (I2C),a	;change to 0 while clock low
;	ld a,5
;ZZ SCL is D[1], SDA is D[0]
	ld a,2
	out (I2C),a	;clock high, data 0
	nop
	nop
;	ld a,4
;ZZ SCL is D[1], SDA is D[0]
	ld a,0
	out (I2C),a	;clock low, data 0
	ret
bit1:
;	ld a,84h
;ZZ SCL is D[1], SDA is D[0]
	ld a,1
	out (I2C),a	;change to 1 while clock low
;	ld a,085h
;ZZ SCL is D[1], SDA is D[0]
	ld a,3
	out (I2C),a	;clock high, data 1
	nop
	nop
;	ld a,84h
;ZZ SCL is D[1], SDA is D[0]
	ld a,1
	out (I2C),a	;clock low, data 1
	ret

	ds 128		;reserve a chunk of memory for stack
stack:

	org 02000h
array:
;64 pixels tall by 128 pixels across, each pixel represented by one byte
	ds 8192
progend:





