;The is the boot loader resides in CF master boot sector (sector 1)
;this program is loaded into memory at 0xB000 and execute
;  It set CF to 8-bit mode, enable LBA
;  then copy program in last 8 sectors of track 0 into memory at 0xb400 and execute

CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

	org 0b080h
;location not to conflict with CPLD bootROM
;stack not used
;	ld sp,0FFFFh	; initialize stack
;I/O page register is already point to 0
	ld a,0ffh		;disable CPLD ROM
	out (1f),a
	ld a,0e0h		;set up LBA mode
	out (CF2427),a	
	ld a,1		; set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		; set feature command
	out (CFstat),a	
readbsy:
	in a,(CFstat)	; check bsy flag first
	and 80h		; bsy flag is at bit 7
	jp nz,readbsy

	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a

	ld d,0f8h		; points to sector to read, last 8 sectors in track 0
	ld hl,0b000h	; store CF data starting from 0b000h
	ld c,CFdata	; reg C points to CF data reg
moresect:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read sector pointed by reg D
;;	cp 0feh		; read sectors 0xF8-0xFD
;;	jp z,0b400h	; load completed, run program loaded at 0xB400
	out (CF07),a	; read the sector pointed by reg D		

	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
readdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq

	ld b,0h		; sector has 512 8-bit data
	inir
	inir

	inc d
	jr nz,moresect
	jp 0b400h


	org 0b200
;1/8/21 some CF disks do not support undo the set feature.
;  set feature to 8-bit and write the same data twice
;  Make sure full 512 bytes of data are written to master boot record
;this is the program that copies the CFbootloader into CF disk at master boot record
;assuming a monitor is already running in B400 that load this program into memory
	ld a,0e0h		;set up LBA mode
	out (CF2427),a
;	ld a,81h		;undo the 8-bit interface
	ld a,1		; set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		; set feature command
	out (CFstat),a	
readbsy2:
	in a,(CFstat)	; check bsy flag first
	and 80h		; bsy flag is at bit 7
	jp nz,readbsy2

	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	out (CF07),a	;master boot block
	inc a		
	out (CFsectcnt),a	;write 1 sector
	ld hl,0b080h	;point to the CFBootLoader

	ld a,30h		;write command
	out (CFstat),a
readdrq1:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq1
morewr:	
	ld a,(hl)		;get a byte of data
	out (CFdata),a	;write both high byte and low byte
	out (CFdata),a	
	inc l
	jp nz,morewr
;at this point only 256 bytes have written, write the same 256 bytes again
	ld l,080h
morewr1
	ld a,(hl)		;get a byte of data
	out (CFdata),a	;write bot high byte and low byte
	out (CFdata),a
	inc l
	jp nz,morewr1
;wait for write to finish
readbsy2a:
	in a,(CFstat)	;read CF status
	and 80h		;mask off all except busy bit
	jp nz,readbsy2a

	jp 0b400		;go back to monitor


	org 0b300h
;copy the monitor into CF disk track 0, sector F8 to FF
; set CF disk to 8-bit LBA mode
	ld a,0e0h		;set up LBA mode
	out (CF2427),a	
	ld a,1		;set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		;set feature command
	out (CFstat),a	
;wait until busy flag is cleared
readbsy3b:
	in a,(CFstat)	;read CF status
	and 80h		;mask off all except busy bit
	jp nz,readbsy3b	
	xor a
	out (CF1623),a	;track 0
	out (CF815),a
	ld d,0f8h		;monitor is stored in sectors F8 to FD
	ld hl,0b000h	;points to beginning of the monitor
	ld c,CFdata
wmoresect:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read sector pointed by reg D
	out (CF07),a	; read the sector pointed by reg D		

	ld a,30h		; write sector command
	out (CFstat),a	; issue the read sector command
readdrq3:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq3

	ld b,0h		; sector has 512 8-bit data
	otir
	otir
;wait for write to finish
readbsy3:
	in a,(CFstat)	;read CF status
	and 80h		;mask off all except busy bit
	jp nz,readbsy3

	inc d
	jr nz,wmoresect
	jp 0b400h


	end 0
