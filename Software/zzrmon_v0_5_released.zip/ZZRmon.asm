;12/16/20 clone from ZZ80Mon
; 512K RAM only at location 0x0
;10/12/20 clone from ver 0.4 of ZZ80CFMon
;This program is expected to run on 512K EPROM strapped to location 0 and 
;  512K RAM strapped to 0x800000
;MMU will be turn on and mapped high memory to RAM and copy EPROM to RAM
;2/8/19 correct xA/B/C/D command
; 2/7/19 Add command 'c1' to store SCMonitor and to run SCMonitor 'b1'
; 2/7/19 Add command 'c3' to store CPM3LDR and 'b3' to boot CPM3
; 11/8/18 ZZ80Mon is renamed ZZ80CFMon so to add CF interface 
;  RAMdisk is removed because I may need the memory for CP/M3
; 8/20/18 v0.26 disable refresh register
;  L ist memory in Intel Hex format
;  I in from port # in I/O page 0
;  O out to port # in I/O page 0
;  Display the ASCII characters along with HEX value
;  show the correct memory address with 'R' command
; 8/11/18 fork from ZZMon v0.99
;  bootstrap monitor for ZZ80RC
;  Resides in physical page 0 (0x0-0xFFF)
;  Immediately after power up, it will make a copy of itself into 0xB400 and jump to it
;  It will enable MMU, write protect physical page 0 and map physical page 0x3C000 to logical page 0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; ZZRMon, Copyright (C) 2020 Hui-chien Shen
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
UARTconf 	equ 10h		; UART configuration register
RxData  	equ 16h        	; on-chip UART receive register
TxData  	equ 18h        	; on-chip UART transmit register
RxStat  	equ 14h        	; on-chip UART transmitter status/control register
TxStat  	equ 12h        	; 0n-chip UART receiver status/control register

CT2Conf	equ 0f8h		;counter 2 configuration
CT2CS	equ 0f9h		;counter 2 command/status
CT2TC	equ 0fah		;counter 2 time constant
CT2CT	equ 0fbh		;counter 2 time (read only)


CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

MMUctrl	equ 0f0h		; MMU master control reg
MMUptr	equ 0f1h		; MMU page descriptor reg pointer
MMUsel	equ 0f5h		; MMU descriptor select port
MMUmove	equ 0f4h		; MMU block move port
MMUinv	equ 0f2h		; MMU invalidation port
DMActrl	equ 01fh		; DMA master control reg
DMA2dstL	equ 10h		; DMA chan 2 destination reg low
DMA2dstH	equ 11h		; DMA chan 2 destination reg high
DMA2srcL	equ 12h		; DMA chan 2 source reg low
DMA2srcH	equ 13h		; DMA chan 2 source reg high
DMA2cnt	equ 14h		; DMA chan 2 count reg
DMA2td	equ 15h		; DMA chan 2 transaction descriptor
DMA3dstL	equ 18h		; DMA chan 3 destination reg low
DMA3dstH	equ 19h		; DMA chan 3 destination reg high
DMA3srcL	equ 1ah		; DMA chan 3 source reg low
DMA3srcH	equ 1bh		; DMA chan 3 source reg high
DMA3cnt	equ 1ch		; DMA chan 3 count reg
DMA3td	equ 1dh		; DMA chan 3 transaction descriptor

	org 0b080		;bootstrap code in master boot block of CF
;this piece of code resides in 0xb080 must be exactily the same as code in master boot block
; as ZZRCC Monitor is copied to 0xb000, this exact code will copy over the bootstrap code
;  while the very bootstrap code is executing
;I/O page register is already point to 0
	ld a,0ffh		;disable CPLD ROM
	out (1f),a
	ld a,0e0h		;set up LBA mode
	out (CF2427),a	
	ld a,1		; set feature to 8-bit interface
	out (CFerr),a	
	ld a,0efh		; set feature command
	out (CFstat),a	
rbsy:
	in a,(CFstat)	; check bsy flag first
	and 80h		; bsy flag is at bit 7
	jp nz,rbsy

	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a

	ld d,0f8h		; points to sector to read, last 8 sectors in track 0
	ld hl,0b000h	; store CF data starting from 0b000h
	ld c,CFdata	; reg C points to CF data reg
moreS:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read sector pointed by reg D
	out (CF07),a	; read the sector pointed by reg D		

	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
rdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,rdrq

	ld b,0h		; sector has 512 8-bit data
	inir
	inir
	inc d
	jr nz,moreS
	jp 0b400h

	org 0b400h
	jp start		;boot table
	jp wboot		;warm boot
	jp syscstat	;console input status
	jp syscin		;console input
	jp syscout	;console output
; variable area
testseed: ds 2		; RAM test seed value
addr3116	ds 2		; high address for Intel Hex format 4
RDsector	ds 1		; current RAM disk sector
RDtrack	ds 1		; current RAM disk track 
RDaddr	ds 2		; current RAM disk address 
WRsector	ds 1		;target sector
WRtrack	ds 1		;target track
RAM4K	ds 1		;RAM in 4K unit, 0 is first 4K, 0x3F is last 4K of 256K RAM
sectoff	ds 2		; offset from a track & sector
readbsysav	ds 1	;scratch memory for readbsy routine


wboot:
	call UARTPage
	jp clrRx
start:
	ld sp,0bfffh	; initialize stack top of monitor
	call ZeroPage
	ld a,0ffh		;disable CPLD ROM
	out (1fh),a
; initialize MMU page descriptors 
; 16 logical pages are mapped to corresponding 16 physical pages
;   of the first 64K of RAM at 0x0
	call MMUPage
	ld a,30h		;disable refresh
	out (0e8h),a

	xor a		; clear reg A 
	out (MMUptr),a	; point to this page (page 0x0), user page descriptors	
	ld hl,MMUtbl	; block move MMU page descriptors
	ld c,MMUmove	; points to MMU block move port
	ld b,16		; move 16 pages
	db 0edh,93h	; op code for otirw, output word and increment
;	otirw
	ld a,10h		; repeat the block move for system page descriptors
	out (MMUptr),a	; point to this page (page 0x0), user page descriptors	
	ld hl,MMUtbl	; block move MMU page descriptors
	ld c,MMUmove	; points to MMU block move port
	ld b,16		; move 16 pages
	db 0edh,93h	; op code for otirw, output word and increment
;	otirw
	ld c,MMUctrl	; point to MMU master control register
	ld hl,0bbffh	; enable user & system  translate
	db 0edh,0bfh	; op code for OUTW (C),HL
;	outw (c),hl	; turn on MMU

;copy 4K from 0xB000 to 0xA000.  0xA000 is mapped to 0x7B000 by MMU
	ld bc,1000h	;block copy 4K from 0xb000 to 0xa000
	ld de,0a000h	;destination
	ld hl,0b000h	;source
	ldir
;map 0xb000 to 0x7b000

	ld a,0bh		;point to User page correspond to 0xb000
	out (MMUptr),a
	ld c,MMUsel
	ld hl,07bah	;RAM is now mapped to 0xb000
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	ld a,1bh		;point to System page correspond to 0xb000
	out (MMUptr),a
	ld hl,7bah	;RAM is now mapped to 0xb000
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl

;map logical 0xa000 to physical 0xa000
	ld a,0ah		;point to User page correspond to 0xa000
	out (MMUptr),a
	ld hl,0aah	;RAM is now mapped to 0xa000
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	ld a,1ah		;point to System page correspond to 0xb000
	out (MMUptr),a
	ld hl,0aah	;RAM is now mapped to 0xa000
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl


;configure UART 
	call UARTPage	;point I/O page to UART
;initialize CT2 to assert CTS handshake
	ld a,0
	out (CT2CS),a	;disable counter 2
	ld c,CT2TC	;oint to counter 2 time count
	ld hl,1		;cause CT2IO to go low
	db 0edh,0bfh	;op code for outw (c),hl
;	outw (c),hl
	ld a,8h		;configure counter2 output
	out (CT2Conf),a
	ld a,80h		;enable counter2
	out (CT2CS),a
;initialize UART
	ld a,0c2h		;115200 N81
	out (UARTconf),A
	ld a,80h		;enable UART transmit
	out (TxStat),a
	out (RxStat),a

    	ld hl,signon$
        	call strout

	call CFPage	; initialize CF flash to 8-bit mode
	call readbsy	;;8 wait until busy flag is cleared
	jr nz,NoCF	;readbsy return Z flag clear if timed out
	ld a,0e0h		;;8 set up LBA mode
	out (CF2427),a	;;8
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8
	call readbsy	;;8 wait until busy flag is cleared
	xor a
	ld (sectoff),a	;initialize (clear) sector offset
	ld (sectoff+1),a
	jr initRAMtst
NoCF:
	call UARTPage
	ld hl,NoCF$
	call strout

initRAMtst:
	call UARTPage
	ld hl,251		; initialize RAM test seed value
	ld (testseed),hl	; save it
clrRx:
	call cstat 
          jr z,CMD
	call cin		;read clear the input buffer
	jr clrRx

;Main command loop
CMD:  	LD HL, PROMPT$
        	CALL strout
CMDLP1:
        	CALL cinq
	cp ':'		; Is this Intel load file?
	jp z,initload
	cp 0ah		; ignore line feed
	jr z,CMDLP1
	cp 0dh		; carriage return get a new prompt
	jr z,CMD
	CALL cout		; echo character
        	AND 5Fh
	cp 'H'		; help command
	jp z,HELP
        	CP A,'D'
        	JP Z,MEMDMP
        	CP A,'E'
        	JP Z,EDMEM
	cp a,'I'		; read data from specified I/O port in page 0
	jp z,INPORT
	cp a,'O'		; write data to specified I/O port in page 0
	jp z,OUTPORT
	cp a,'L'		; list memory as Intel Hex format
	jp z,LISTHEX
        	CP A,'G'
        	JP Z,go
	cp a,'R'		; read a CF sector
	jp z,READRD
	cp a,'Z'		; fill memory with zeros
	jp z,fillZ
	cp a,'F'		; fill memory with ff
	jp z,fillF
	cp a,'C'		; Copy to CF	
	jp z,COPYCF
	cp a,'T'		; testing RAM 
	jp z,TESTRAM
	cp 'B'		; boot CPM
	jp z,BootCPM
	cp 'X'		; clear RAMdisk directory at 0x80000
	jp z,format
what:
        	LD HL, what$
        	CALL strout
        	jr CMD
abort:
	ld hl,abort$	; print command not executed
	call strout
	jr CMD
readbsy:
; spin on CF status busy bit
;Z flag set (equal) if CF not busy
;Z flag reset (not equal) if timed out
	ld (readbsysav),a	;save reg A
	push de
	push bc
	ld de,0		;set a timeout limit
	ld bc,30
readbsy1
	inc de
	ld a,d
	or e
	jr nz,moreRdBsy
	dec c
	jr nz,moreRdBsy
	xor a
	inc a		;clear Z flag
	pop bc
	pop de
	ld a,(readbsysav)	;restore regA, but not status flags
	ret
moreRdBsy:
	in a,(CFstat)	; read CF status 
	and 80h		; mask off all except busy bit
	jr nz,readbsy1
	pop bc
	pop de
	ld a,(readbsysav)	;restore regA, but not status flags
	ret

; initialize for file load operation
initload:
	ld hl,0		; clear the high address in preparation for file load
	ld (addr3116),hl	; addr3116 modified with Intel Hex format 4 
; load Intel file
fileload:
	call GETHEXQ	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a		; save byte count to reg D
	ld c,a		; save copy of byte count to reg C
	ld b,a		; initialize the checksum
	call GETHEXQ	; get MSB of address
	ld h,a		; HL points to memory to be loaded
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get LSB of address
	ld l,a
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the record type, 0 is data, 1 is end
	cp 0
	jr z,filesave
	cp 1		; end of file transfer?
	jr z,fileend
	cp 4		; Extended linear address?
	jp nz,unknown	; if not, print a 'U'
; Extended linear address for greater than 64K
; this is where addr3116 is modified
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,d		; byte count should always be 2
	cp 2
	jp nz,unknown
	call GETHEXQ	; get first byte (MSB) of high address
	ld (addr3116+1),a	; save to addr3116+1
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
; Little Endian format.  MSB in addr3116+1, LSB in addr3116
	call GETHEXQ	; get the 2nd byte (LSB) of of high address
	ld (addr3116),a	; save to addr3116
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jp nz,badload	; checksum not match, put '?'
	ld a,'E'		; denote a successful Extended linear addr update
	jp filesav2
; end of the file load
fileend:
	call GETHEXQ	; flush the line, get the last byte
	ld hl,fileEnd$	;mark end of file with 'X'
	call strout
	jp CMD
; the assumption is the data is good and will be saved to the destination memory
filesave:
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld ix,0b000h	; logical 0b000h is buffer for incoming data

filesavx:
	call GETHEXQ	; get a byte
	ld (ix),a		; save to buffer
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	inc ix
	dec d
	jr nz,filesavx
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jr nz,badload	; checksum not match, put '?'
	call DMAPage	; set page i/o reg to DMA
; use DMA to put data from buffer to location pointed by ehl
	push hl		; destination RAM in hl, save it for now
	ld b,0		; clear out MSB of reg BC, reg C contains the saved byte count
	push bc		; DMA count is in reg BC, save it 
; set up DMA master control
	ld c,DMActrl	; set up DMA master control
	ld hl,0f0e0h	; software ready for dma0&1, no end-of-process, no links
;	outw (c),hl	; write DMA master control reg
	db 0edh,0bfh	; op code for OUTW (C),HL
; set up DMA count register 
	ld c,DMA3cnt	; setup count of 128 byte
	pop hl		; transfer what was saved in bc into hl
;	outw (c),hl	; write DMA3 count reg
	db 0edh,0bfh	; op code for OUTW (C),HL
; source buffer starts at 0x0b000  <- remember DMA works with physical address of RAM 
;  logical 0b000 is mapped to physical 0x7b000
	ld c,DMA3srcH	; source is physical 0x7b000
	ld hl,07bfh	; A23..A12 are 0x7b		
;	outw (c),hl	; write DMA3 source high reg
	db 0edh,0bfh	; op code for OUTW (C),HL
	ld c,DMA3srcL	;physical address of buffer is 0x7b000
	ld hl,0f000h	; A11..A0 are 0x000
;	outw (c),hl	; write DMA3 source low reg
	db 0edh,0bfh	; op code for OUTW (C),HL	
; destination buffer is in e + hl (saved in stack right now)
	ld c,DMA3dstH
	ld a,(addr3116)	; get A23..A16 value into reg H
;no need for next instruction, RAM is at 0x0
;	or 80h		;RAM is at 0x800000, so A23 is set to 1
	ld h,a		; 	
	pop de		; restore saved hl into de

	ld l,d		; move A15..A8 value
	ld a,0fh		; force lowest nibble of DMA3dstH to 0xF
	or l
do_dma3hi:
;	outw (c),hl	; write DMA3 destination high reg
	db 0edh,0bfh	; op code for OUTW (C),HL
	ld c,DMA3dstL
	ld h,d		; reg DE contain A15..A0 value
	ld l,e
	ld a,0f0h		; force highest nibble of DMA3dstL to 0xF
	or h
;	outw (c),hl	; write DMA3 destination low reg
	db 0edh,0bfh	; op code for OUTW (C),HL
; write DMA3 transaction description reg and start DMA
	ld hl,8080h	; enable DMA3, burst, byte size, flowthrough, no interrupt
;			;  incrementing memory for source & destination
	ld c,DMA3td	; setup DMA3 transaction descriptor reg
;	outw (c),hl	; write DMA3 transaction description reg
	db 0edh,0bfh	; op code for OUTW (C),HL
;  DMA should start now
	call UARTPage	; set page i/o reg to default

	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr flushln	; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
flushln:
	call cinq		; keep on reading until ':' is encountered
	cp ':'
	jr nz,flushln
	jp fileload
; format CF drives directories 
; drive A directory is track 1, sectors 0-0x1F
; drive B directory is track 0x40, sectors 0-0x1F
; drive C directory is track 0x80, sectors 0-0x1F
; drive D directory is track 0xC0, sectors 0-0x1F
format:
	ld hl,clrdir$	; command message
	call strout
	call cin
	cp 'A'
	jr z,formatA	; fill track 1 sectors 0-0x1F with 0xE5
	cp 'B'
	jr z,formatB	; fill track 0x40 sectors 0-0x1F with 0xE5
	cp 'C'
	jr z,formatC	; fill track 0x80 sectors 0-0x1F with 0xE5
	cp 'D'
	jr z,formatD	; fill track 0xC0 sectors 0-0x1F with 0xE5
	jp abort		; abort command if not in the list of options
formatA:
	ld de,100h	; start with track 1 sector 0
	jr doformat
formatB:
	ld de,4200h	; start with track 0x40 sector 0
	jr doformat
formatC:
	ld de,8300h	; start with track 0x80 sector 0
	jr doformat
formatD:
	ld de,0c400h	; start with track 0xC0 sector 0
doformat:
	ld hl,warning$	; warning & confirm command execution
	call strout
	call tstY
	jp nz,abort	; abort command if not CRLF
	call CFPage	; initialize page i/o reg to CF
	ld a,0E0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; MSB track is 0
	ld a,d		; reg D contains the track info
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
	ld hl,0e5e5h	; value for empty directories
wrCFf:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,e		; write CPM sector
	cp 20h		; format sector 0-0x1F
	jr z,wrCFdonef	; done formatting
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
loopf:
	out (c),h		; fill directory with 0xE5
	out (c),h	
	inc b
	jr nz,loopf

	call readbsy	;spin on CF status busy bit
	inc e		; write next sector
	jr wrCFf
wrCFdonef:
	call UARTPage	; set page i/o reg to internal UART
	jp CMD
chkdrq:
	in a,(CFstat)	; check data request bit set before write CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,chkdrq
	ret

INPORT:
; read data from specified I/O port in page 0
; command format is "I port#"
; 
	ld hl,inport$	; print command 'I' prompt
	call strout
	call GETHEX	; get port # into reg A
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD
	push bc		; save register
	ld c,a		; load port # in reg C
	call ZeroPage	; The I/O port resides in page 0
	in b,(c)		; get data from port # into reg B
	call UARTPage
	ld hl,invalue$
	call strout
	ld a,b
	call HEXOUT
	pop bc		; restore reg
	jp CMD
OUTPORT:
; write data to specified I/O port in page 0
; command format is "O value port#"
	ld hl,outport$	; print command 'O' prompt
	call strout
	call GETHEX	; get value to be output
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD	
	push bc		; save register
	ld b,a		; load value in reg B
	ld hl,outport2$	; print additional prompt for command 'O'
	call strout
	call GETHEX	; get port number into reg A
	jr c,OUTPORT9	;abort for non-hexdecimal input
	jr z,OUTPORT9
	ld c,a
	call ZeroPage	; The I/O port resides in page 0
	out (c),b		; output data in regB to port in reg C
	call UARTPage
OUTPORT9:
	pop bc
	jp CMD
LISTHEX:
; list memory as Intel Hex format
; the purpose of command is to save memory as Intel Hex format to console
	ld hl,listhex$	; print command 'L' prompt
	call strout
	call ADRIN	; get address word into reg DE
	jp z,CMD		;return to command prompt if illegal input
	push de		; save for later use
	ld hl,listhex1$	; print second part of 'L' command prompt
	call strout
	call ADRIN	; get end address into reg DE
	jp z,CMD		;return to command prompt if illegal input
listhex1:
	ld hl,CRLF$	; put out a CR, LF	
	call strout
	ld c,10h		; each line contains 16 bytes
	ld b,c		; reg B is the running checksum
	ld a,':'		; start of Intel Hex record
	call cout
	ld a,c		; byte count
	call HEXOUT
	pop hl		; start address in HL
	call ADROUT	; output start address
	ld a,b		; get the checksum
	add a,h		; accumulate checksum
	add a,l		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	xor a		
	call HEXOUT	; record type is 00 (data)
listhex2:
	ld a,(hl)		; get memory pointed by hl
	call HEXOUT	; output the memory value in hex
	ld a,(hl)		; get memory again
	add a,b		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	inc hl
	dec c
	jr nz,listhex2
	ld a,b		; get the checksum
	neg a
	call HEXOUT	; output the checksum
; output 16 memory location, check if reached the end address (saved in reg DE)
; unsign compare: if reg A < reg N, C flag set, if reg A > reg N, C flag clear
	push hl		; save current address pointer
	ld a,h		; get MSB of current address
	cp d		; reg DE contain the end address
	jr nc,hexend	; if greater, output end-of-file record
	jr c,listhex1	; if less, output more record
; if equal, compare the LSB value of the current address pointer
	ld a,l		; now compare the LSB of current address
	cp e
	jr c,listhex1	; if less, output another line of Intel Hex
hexend:
; end-of-record is :00000001FF
	ld hl,hexEnd$
	call strout
	pop hl		; clear up the stack
	jp CMD

; print help message
HELP:
	ld hl,HELP$	; print help message
	call strout
	call ZeroPage
	call readbsy	;;8 wait until busy flag is cleared
	jp nz,NoCF	;readbsy return Z flag clear if timed out
	ld a,0e0h		;;8 set up LBA mode
	out (CF2427),a	;;8
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8
	call UARTPage
	jp CMD
; boot CPM
; copy program from LA9-LA26 (9K) to 0xDC00
; jump to 0xF200 after copy is completed.
BootCPM:
	ld hl,bootcpm$	; print command message
	call strout
	call cin		; get input
	cp '1'		; '1' is user apps
	jr z,bootApps
	cp '2'		; '2' is cpm2.2
	jr z,boot22
;	cp '3'		; '3' is cpm3, not implemented
;	jr z,boot3
	cp '4'		;'4' is ROMWBW
	jp z,bROMWBW
	jp what

boot22:
;  jump into 0xF200 after copy completed
	ld hl,confirm$	; carriage return to execute the program
	call strout
	call tstCRLF
	jp nz,abort	; abort command if not CR or LF

	call CFPage	; initialize page i/o reg to CF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
	ld c,CFdata	; reg C points to CF data reg
	ld d,80h		; read from LA 0x80 to LA 0x92
readCPM1:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 92h		; between LA80h and LA91h
	jr z,goCPM	; done copying, execute CPM
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		; 8-bit wide CF interface
	inir		; 8-bit wide CF interface
	inc d		; read next sector
	jr readCPM1
goCPM:
	call UARTPage	; set page i/o reg to internal UART
	jp 0f200h		; BIOS starting address of CP/M

bootApps:
; User applications resides in CF sector 0x11-0x68.  
; Copy it to 0x0-0xAFFF and jump to 0x0
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
	call CFPage	; initialize page i/o reg to CF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,0		; user apps starts from 0x0
	ld c,CFdata	; reg C points to CF data reg
	ld d,11h		; read from LA 0x11 to LA 0x68
readApp1:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 69h		; between LA11h and LA68h
	jr z,goApps	; done copying, execute user apps
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		; 8-bit wide CF interface
	inir		; 8-bit wide CF interface
	inc d		; read next sector
	jr readApp1
goApps:
	call UARTPage	; set page i/o reg to internal UART
	jp 0h		; User apps starts at 0x0
bROMWBW:
;copy the program located in LBA 0x148 to 0x150 to RAM at 0x5000 and jump to 0x5003
;  LBA 0x148 correspond to physical memory 0x5000.  A 8K hole exists in ROMWBW 
;   from 0x5000-0x6fff for non-ROMWBW code prior to ROMWBW execution
;   ROMWBWldr utilizes the space for code, DMA buffer, and MMU windows to copy/restore
;   ROMWBW to RAM.  Location 0x5003 jumps to the restore CF-to-RAM routine
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
	jp btROMWBW

; fill memory from end of program to 0xFFFF with zero or 0xFF
; also fill memory from 0x0 to 0xB000 with zero or 0xFF
fillZ:
	ld hl,fill0$	; print fill memory with 0 message
	call strout
	ld b,0		; fill memory with 0
	jr dofill
fillF:
	ld hl,fillf$	; print fill memory with F message
	call strout
	ld b,0ffh		; fill memory with ff
dofill:
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld hl,PROGEND	; start from end of this program
	ld a,0ffh		; end address in reg A
filla:
	ld (hl),b		; write memory location
	inc hl
	cp h		; reached 0xFF00?
	jr nz,filla	; continue til done
	cp l		; reached 0xFFFF?
	jr nz,filla
	ld hl,0b000h	; fill value from 0xB000 down to 0x0000
fillb:
	dec hl
	ld (hl),b		; write memory location with desired value
	ld a,h		; do until h=l=0
	or l
	jr nz,fillb
	jp CMD
; Read CF disk
; data buffer is at 0xc000
READRD:
	ld hl,read$	; put out read command message
	call strout
	ld hl,track$	; enter track in hex value
	call strout
	call GETHEX	; get a byte of hex value as track
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD
	ld (RDtrack),a	; save it 
	ld hl,sector$	; enter sector in hex value
	call strout
	call GETHEX	; get a byte of hex value as sector
	jp c,CMD		;abort for non-hexdecimal input
	jp z,CMD
	ld (RDsector),a	; save it
READRD1:
;	ld hl,1000h	; copy previous block to 2000h
;	ld de,2000h
;	ld bc,200h	; copy 512 bytes
;	ldir		; block copy
	call CFPage	; set page i/o reg to page 0
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,0		; read first sector
	out (CF1623),a	; high byte of track is always 0
	ld a,(RDsector)	; get sector value
	out (CF07),a	; write sector
	ld a,(RDtrack)
	out (CF815),a
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	;check data request bit set before write CF data
	ld hl,0c000h	; store CF data starting from 0xc000
	ld c,CFdata	; reg C points to CF data reg
	ld b,0h		; sector has 256 16-bit data
	inir		;
	inir
	call UARTPage	; set page i/o reg to internal UART
dumpdata:
	ld d,32		; 32 lines of data
	ld hl,0c000h	; display 512 bytes of data
dmpdata1:
	push hl		; save hl
	ld hl,CRLF$	; add a CRLF per line
	call strout
	pop hl		; hl is the next address to display
	call DMP16TS	; display 16 bytes per line
	dec d
	jr nz,dmpdata1

;	ld hl,1000h	; compare with data block in 2000h
;	ld bc,200h
;	ld de,2000h
;blkcmp:
;	ld a,(de)		; get a byte from block in 2000h
;	inc de
;	cpi		; compare with corresponding data in 1000h
;	jp po,blkcmp1	; exit at end of block compare
;	jr z,blkcmp	; exit if data not compare
;	ld hl,notsame$	; send out message that data not same as previous read
;	call strout
;	jr chkRDmore
;blkcmp1:	
;	ld hl,issame$	; send out message that data read is same as before
;	call strout

chkRDmore:
	ld hl,0		;clear sector offset value
	ld (sectoff),hl
	ld hl,RDmore$	; carriage return for next sector of data
	call strout
	call tstCRLF	; look for CRLF
	jp nz,CMD		; 
	ld hl,(RDsector)	; load track & sector as 16-bit value
	inc hl		; increment by 1
	ld (RDsector),hl	; save updated values
	ld hl,track$	; print track & sector value
	call strout
	ld a,(RDtrack)
	call HEXOUT
	ld hl,sector$
	call strout
	ld a,(RDsector)
	call HEXOUT
	jp READRD1

; Write CF
;  allowable parameters are '0' for boot sector & ZZMon, '1' for 32K apps, 
;   '2' for CPM2.2, '3' for CPM3
; Set page I/O to 0, afterward set it back to 0FEh
COPYCF:
	ld hl,copycf$	; print copy message
	call strout
	call cin		; get write parameters
	cp '0'
	jp z,cpBoot
	cp '1'
	jr z,cpAPPS
	cp '2'
	jr z,CopyCPM2
	cp '4'
	jp nz,what	;error, abort command
	ld hl,warning$	; warning and look for Y to execute the program
	call strout
	call tstY
	jp nz,abort	; abort command if not CR or LF
	jp cpROMWBW

; test for CR or LF.  Echo back. return 0
tstCRLF:
	call cin		; get a character					
	cp 0dh		; if carriage return, output LF
	jr z,tstCRLF1
	cp 0ah		; if line feed, output CR 
	jr z,tstCRLF2
	ret
tstCRLF1:
	ld a,0ah		; put out a LF
	call cout
	xor a		; set Z flag
	ret
tstCRLF2:
	ld a,0dh		; put out a CR
	call cout
	xor a		; set Z flag
	ret
; test for Y and set condition flag
tstY:
	call cin		;get a character
	cp 'Y'
	ret
; write CPM to CF
; write data from 0xDC00 to 0xFFFF to CF LA128-LA146 (9K)
CopyCPM2:
	ld hl,0dc00h	; CPM starts from 0xDC00 to 0xFFFF
	ld de,8092h	; reg DE contains beginning sector and end+1 sector values
	jr wrCF
cpBoot:
	ld hl,0b000h	;ZZRCC monitor resides from 0xB000-0xBFFF
	ld de,0f800h	; reg DE contains beginning and end+1 sector values
	jr wrCF
cpAPPS:
; write User application to CF
; user application is from 0x0 to 0xAFFF
	ld hl,0		; Application starts from 0 to 0xAFFF
	ld de,1168h	; reg DE contains beginning sector and end sector values
wrCF:
	push hl		; save value
	ld hl,warning$	; carriage return to execute the program
	call strout
	pop hl
	call tstY
	jp nz,abort	; abort command if not CR or LF
	call CFPage	; initialize page i/o reg to CF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
wrCF1:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; write CPM sector
	cp e		; reg E contains end sector value
	jr z,wrCFdone	; done copying, execute CPM
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	otir		; 8-bit CF interface
	otir		; 8-bit CF interface
	call readbsy	;spin on CF status busy bit
	inc d		; write next sector
	jr wrCF1
wrCFdone:
	call UARTPage	; set page i/o reg to internal UART
	jp CMD
	
TESTRAM:
; test memory from top of this program to 0xFFFE 
	ld hl,testram$	; print test ram message
	call strout
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld iy,(testseed)	; a prime number seed, another good prime number is 211
TRagain:
	ld hl,PROGEND	; start testing from the end of this program
	ld de,137		; increment by prime number
TRLOOP:
	push iy		; bounce off stack
	pop bc
	ld (hl),c		; write a pattern to memory
	inc hl
	ld (hl),b
	inc hl
	add iy,de		; add a prime number
	ld a,0ffh		; compare h to 0xff
	cp h
	jr nz,TRLOOP	; continue until reaching 0xFFFE
	ld a,0feh		; compare l to 0xFE
	cp l
	jr nz,TRLOOP
	ld hl,0b000h	; test memory from 0xAFFF down to 0x0000
TR1LOOP:
	push iy
	pop bc		; bounce off stack
	dec hl
	ld (hl),b		; write MSB
	dec hl
	ld (hl),c		; write LSB
	add iy,de		; add a prime number
	ld a,h		; check h=l=0
	or l
	jr nz,TR1LOOP
	ld hl,PROGEND	; verify starting from the end of this program
	ld iy,(testseed)	; starting seed value
TRVER:
	push iy		; bounce off stack
	pop bc
	ld a,(hl)		; get LSB
	cp c		; verify
	jr nz,TRERROR
	inc hl
	ld a,(hl)		; get MSB
	cp b
	jr nz,TRERROR
	inc hl
	add iy,de		; next reference value
	ld a,0ffh		; compare h to 0xff
	cp h
	jr nz,TRVER	; continue verifying til end of memory
	ld a,0feh		; compare l to 0xFE
	cp l
	jr nz,TRVER
	ld hl,0b000h	; verify memory from 0xB000 down to 0x0000
TR1VER:
	push iy		; bounce off stack
	pop bc
	dec hl
	ld a,(hl)		; get MSB from memory
	cp b		; verify
	jr nz,TRERROR
	dec hl
	ld a,(hl)		; get LSB from memory
	cp c
	jr nz,TRERROR
	add iy,de
	ld a,h		; check h=l=0
	or l
	jr nz,TR1VER
	call SPCOUT	; a space delimiter
	ld a,'O'		; put out 'OK' message
	call cout
	ld a,'K'
	call cout
	ld (testseed),iy	; save seed value

	call cstat	;check for keyboard input
	jr z,TRagain	;no char input, do another iteration of memory test
	call cin		;read clear the input
	jp CMD
TRERROR:
	call SPCOUT	; a space char to separate the 'r' command
	ld a,'H'		; display content of HL reg
	call cout		; print the HL label
	ld a,'L'
	call cout
	call SPCOUT	
	call ADROUT	; output the content of HL 	
	jp CMD

;Get an address and jump to it
go:
	ld hl,go$		; print go command message
	call strout
        	CALL ADRIN
	jp z,CMD		;abort command with illegal input
        	LD H,D
        	LD L,E
	push hl		; save go address
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	pop hl
	jp nz,abort
	call ZeroPage	;set I/O page to zero
	db 0edh,065h	;op code for PCACHE instruction
	jp (hl)		; jump to address if CRLF

;;;;;;;;;;;;;;;;;;;;;;;;;;; Utilities from Glitch Works ver 0.1 ;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;; Copyright (C) 2012 Jonathan Chapman ;;;;;;;;;;;;;;;;;;

;Edit memory from a starting address until X is
;pressed. Display mem loc, contents, and results
;of write.
EDMEM:  	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command with illegal input
        	LD H,D
        	LD L,E
EDMEM1:    	
	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL ADROUT
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	CALL SPCOUT
        	CALL DMPLOC
        	CALL SPCOUT
        	CALL GETHEX
	jp c,CMD		;abort for illegal input
 	jr z,EDMEM2	;handle CR, -, x inputs
        	JP C,CMD
        	LD (HL),A
        	CALL SPCOUT
        	CALL DMPLOC
        	INC HL
        	jr EDMEM1
EDMEM2:
;handle non-hexdecimal input of CR, -, x or X
	cp '-'		;go to previous location
	jr nz,EDMEM3
	dec hl
	jr EDMEM1
EDMEM3:
	cp 0dh		;go to next location
	jp nz,CMD		;abort command for all other non-hex input
	inc hl
	jr EDMEM1

;Dump memory between two address locations
MEMDMP: 	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command if illegal input
        	LD H,D
        	LD L,E
        	LD C,10h
        	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command if illegal input
MD1:    	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL DMP16
        	LD A,D
        	CP H
        	JP M,CMD
        	LD A,E
        	CP L
        	jp M,MD2
        	jr MD1
MD2:    	LD A,D
        	CP H
        	jr NZ,MD1
        	JP CMD

DMP16TS:
; dump memory pointed by HL, 
; print offset from the given track & sector values
;  as the address field
	push hl		; save reg
	ld a,'+'		;print offset symbol
	call cout
	ld hl,(sectoff)	;get offset from track&sector base
	call ADROUT	; output A23..A8
	push bc		;save reg
	ld bc,10h		;add 16 to offset
	add hl,bc
	pop bc
	ld (sectoff),hl	;save it
	pop hl		; restore reg
	jr DMP16D		; display the 16 data field

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMP16 -- Dump 16 consecutive memory locations
;
;pre: HL pair contains starting memory address
;post: memory from HL to HL + 16 printed
;post: HL incremented to HL + 16
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMP16:  	CALL ADROUT
DMP16D:			; 16 consecutive data
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	LD C,10h
	push hl		; save location for later use
DM1:    	CALL SPCOUT
        	CALL DMPLOC
        	INC HL		
        	DEC C
	jr nz,DM1

; display the ASCII equivalent of the hex values
	pop hl		; retrieve the saved location
	ld c,10h		; print 16 characters
	call SPCOUT	; insert two space
	call SPCOUT	; 
dm2:
	ld a,(hl)		; read the memory location
	cp ' '
	jp m,printdot	; if lesser than 0x20, print a dot
	cp 7fh
	jp m,printchar
printdot:
; for value lesser than 0x20 or 0x7f and greater, print '.'
	ld a,'.'
printchar:
; output printable character
	call cout
	inc hl
	dec c
	ret z
	jr dm2

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMPLOC -- Print a byte at HL to console
;
;pre: HL pair contains address of byte
;post: byte at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMPLOC: 	LD A,(HL)
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXOUT -- Output byte to console as hex
;
;pre: A register contains byte to be output
;post: byte is output to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXOUT: 	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	POP BC
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXASC -- Convert nybble to ASCII char
;
;pre: A register contains nybble
;post: A register contains ASCII char
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXASC: 	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADROUT -- Print an address to the console
;
;pre: HL pair contains address to print
;post: HL printed to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADROUT: 	LD A,H
        	CALL HEXOUT
        	LD A,L
        	CALL HEXOUT
        	RET


; get hex without echo back
GETHEXQ:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GOBYT -- Push a two-byte instruction and RET
;         and jump to it
;
;pre: B register contains operand
;pre: C register contains opcode
;post: code executed, returns to caller
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GOBYT:  	LD HL,0
        	ADD HL,SP
        	DEC HL
        	LD (HL),0C9h
        	DEC HL
        	LD (HL),B
        	DEC HL
        	LD (HL),C
        	JP (HL)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;SPCOUT -- Print a space to the console
;
;pre: none
;post: 0x20 printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
SPCOUT: 	LD A,' '
        	CALL cout
        	RET
;ADRIN -- Get up to 4 bytes address from console in reg DE
; if illegal address, set Z flag
;
;pre: none
;post: DE contains address from console
ADRIN:
	ld de,0		
	call cin
	call ASCHEX	;get a hex value
; none hex value will end command
	jr z,exit0
	ld e,a		;save
backup1:		
	call cin
	cp 8		;backspace?
	jr z,ADRIN	;start over
  	call ASCHEX
;possible options here are 
; backspace
; space to advance command
; other none hex to terminate command
	jr z,exit123
	sla e
	sla e
	sla e
	sla e
	or e
	ld e,a		;save to reg E
getChar3:
	call cin
	cp 8
	jr z,backupE
	call ASCHEX
	jr z,exit123
	call addChar
	call cin
	cp 8
	jr z,delChar
	call ASCHEX
	jr z,exit123	;exit with 3 characters entered
	call addChar
	cp 0ffh		;regA is never 0xff so clear Z flag
	ret
backupE:
;shift regE back a nibble
	srl e
	srl e
	srl e
	srl e
	jr backup1
delChar:
;shift DE back a nibble
	sra d
	rr e
	sra d
	rr e
	sra d
	rr e
	sra d
	rr e
	ld d,0
	jr getChar3
addChar:
;shift DE forward a nibble and add reg A
	sla e
	rl d
	sla e
	rl d
	sla e
	rl d
	sla e
	rl d
	or e
	ld e,a
	ret
exit123
;if space or CR, return with Z flag cleared and valid data in DE
	cp ' '
	jr z,exitGood
	cp 0dh
	jr z,exitGood
exit0:
	xor a		;set Z flag
	ret
exitGood:
	or a		;regA is either space or CR, so this will clear Z flag
	ret

;Get hex in regA
; set C flag to abort the operation <-expect calling routine to chk C flag first
; set Z flag to signal different action for calling routine:
;  x terminate command
;  - go back to previous memory location
;  CR next memory location
GETHEX0:
	call cout		;echo back
	pop de		;start over but first undo the regDE push
GETHEX:
        	CALL cin
        	CALL ASCHEX
;valid first character are:
; hexdecimal value
;  CR,x,-  to be handled by calling routine
;  
	ret z		;not valid hex
	push de
        	LD D,A		;save to combine with 2nd input
        	CALL cinq		;don't automatic echo back on 2nd character
			;supress echo back of CR
;valid second character are:
; hexdecimal value,
; CR: one digit input
; BS: go back to beginning
; otherwise abort the command using C flag for signalling
	cp 8		;back space?
	jr z,GETHEX0	;start over
	cp 0dh		;no echo back for CR
	jr nz,GE0
	or a		;clear Z flag
	ld a,d		;restore the one digit result
	pop de
	ret
GE0:
	call cout		;echo back
	call ASCHEX
	jr z,GE2
	sla d		;shift first hex input to high nibble
	sla d
	sla d
	sla d
        	or d		;combine with 2nd hex input
        	                  ;be careful, this operation may set Z flag is result is zero
        	ld d,1            ;take care of the case when result is 0 and Z flag set
	inc d		;this will clear the Z flag
GE1:    	pop de
	ret
GE2:    	scf
	pop de
	ret
;ASCHEX, convert ASCII to low nibble
;return Z flag set if not 0-9, A-F
; original value in regA returned if not hexdecimal character
ASCHEX: 	
	sub 30h		;ascii 0 is 0x30
	jp m,invalidx
	cp 0ah		;0-9?
	ret m
	sub 11h		;ascii A is 0x41
	jp m,invalidy
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;A-F?
	ret m
	sub 2ah		;ascii a is 0x61
	jp m,invalidz
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;a-f?
	ret m
invalidz
	add 20h-0ah	;return reg A to original value
invalidy
	add 11h
invalidx
	add 30h
	cp a		;set Z flag
	ret		;return with original regA and Z flag set

;send null-terminated string to console
strout: 	
	
	ld a,(hl)
	or a
	ret z
	call cout
	inc hl
	jr strout

; init page i/o reg to point to UART or Counter/Timer
UARTPage:
CTPage:
	push hl		; save register
	ld l,0feh		; set I/O page register to 0xFE
	jr setpage
; initialize Z280 page i/o reg to point to MMU and DMA
DMAPage:
MMUPage:
	push hl		; save register
	ld l,0ffh		; MMU and DMA page I/O reg is 0xFF
	jr setpage
; init page i/o reg to point to compactflash
ZeroPage:
CFPage:
	push hl		; save register
	ld l,0		; set I/O page register to 0

setpage:
	push bc		; save more reg
	ld c,08h		; reg c points to I/O page register
; reg L is already pre-loaded with correct page value
	db 0edh,6eh	; this is the op code for LDCTL (C),HL
	pop bc		; restore reg
	pop hl
	ret
syscstat:
;check console input available, Z set if no data, Z clear if data available
	call UARTPage
	call cstat
	call ZeroPage
cstat:
;Check console input status, return 0 with Z set if no character available
	in a,(RxStat)	;read on-chip UART status
	and 10h
	ret
syscin:
;system call to input a character in regA
	call UARTPage
	call cin
	call ZeroPage
;Get a char from the console and echo
cin:    
        	IN A,(RxStat)	; read on-chip UART receive status
        	AND 10H				;;Z data available?
        	jr Z,cin
        	IN A,(RxData)	; save to reg A
        	OUT (TxData),A	; echo back
        	RET
; get char from console without echo
cinq:
        	IN A,(RxStat)	; read on-chip UART receive status
        	AND 10H				;;Z data available?
        	jr Z,cinq
        	IN A,(RxData)	; save to reg A
        	RET
syscout:
;system call to put a character out in regA
	call UARTPage
	call cout
	call ZeroPage
cout:
;Output a character in regA to the console   
	push af		; save data to be printed to stack
cout1:  	IN A,(TxStat)	; transmit empty?
        	rra
        	jr nc,cout1
	pop af		; restore data to be printed
        	OUT (TxData),A	; write it out
        	RET

;MMUtbl	ds 32		; 16 pages of system MMU page descriptors
;map logical 0xA000-0xAFFF to 0x7B000-0x7BFFF
; so 4K monitor program can be copied from 0xB000 to 0xA000
; and then map logical 0xB000-0xBFFF to 0x7B000-0x7BFFF
MMUtbl	db 0ah,0,1ah,0,2ah,0,3ah,0,4ah,0,5ah,0,6ah,0,7ah,0
	db 8ah,0,9ah,0,0bah,7,0bah,0,0cah,0,0dah,0,0eah,0,0fah,0

;PROGEND:	equ $		; end of the program
PROGEND:	equ 0c000h		; end of the program 


signon$:	db " ZZRCC Monitor v0.5 4/16/21", 13,10,0 
NoCF$:	db 13,10,"no CF disk",13,10,0
PROMPT$:	db 13, 10, 10, ">", 0
what$:   	db 13, 10, "?", 0
fileEnd$	db "X"
CRLF$	db 13,10,0
confirm$	db " press Return to execute command",0
abort$	db 13,10,"command aborted",0
warning$	db " System files in CF disk will be modified.  Type Y to proceed ",0
notdone$	db 13,10,"command not implemented",0
go$	db "o to address: 0x",0
track$	db " track:0x",0
sector$	db " sector:0x",0
read$	db "ead CF disk",0
RDmore$	db 10,13,"Return for next sector, any other key for command prompt",10,13,0
;notsame$	db 10,13,"Data NOT same as previous read",10,13,0
;issame$	db 10,13,"Data same as previous read",10,13,0
inport$	db "nput from port ",0
invalue$	db 10,13,"Value=",0
outport$	db "utput ",0
outport2$	db " to port ",0
listhex$	db "ist memory as Intel Hex, start address=",0
listhex1$	db " end address=",0
hexEnd$	db 10,13,":00000001FF",0
fillf$	db "ill memory with 0xFF",10,13,0
fill0$	db "ero memory",10,13,0
testram$	db "est memory",10,13,0



copycf$	db "opy to CF disk",10,13
	db "0--boot,",10,13
	db "1--User Apps,",10,13
	db "2--CP/M2.2,",10,13
	db "4--ROMWBW:"
	db 0
clrdir$	db " clear disk directories",10,13
	db "A -- drive A,",10,13
	db "B -- drive B:",10,13
	db "C -- drive C,",10,13
	db "D -- drive D,",10,13	
	db 0

	org 0b100h	;running out of space, put some text file in 0b100h

bootcpm$	db "oot",10,13
	db "1--User App:",10,13
	db "2--CP/M 2.2:",10,13
;	db "3--CP/M 3:",10,13
	db "4--ROMWBW:"
	db 0

HELP$	db "elp",13,10
	db "G <addr> CR",13,10
	db "R <track> <sector>",13,10
	db "D <start addr> <end addr>",13,10
	db "I <port>",13,10
	db "O <value> <port>",13,10
	db "L <start addr> <end addr>",13,10
	db "Z CR",13,10
	db "F CR",13,10
	db "T CR",13,10
	db "E <addr>",13,10
	db "X <options> CR",13,10
	db "B <options> CR",13,10
	db "C <options> CR",0

	org 0b250h	;program is just above CFbootloader
;write low 256K of RAM to CF disk
; write the ROMWBW.img to directory
; write ROMWBW to sector 0x120-0x320
; Use 4K page at logical address 0x0-0xFFF as buffer
; copy 0x0-0xFFF out to CF first, then use it as buffer to copy rest of 256K to CF
cpROMWBW:
	xor a
	ld (RAM4K),a
	inc a
	ld (WRtrack),a	;initialize track to 1
	ld a,20h
	ld (WRsector),a	;initialize sector to 0x20
	ld hl,0ah		;start with lowest 4K of 512K RAM
	jr wrEntry	
more4K:
	call MMUPage
	ld a,0h		;point to User page correspond to 0x0
	out (MMUptr),a
	ld c,MMUsel
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	ld a,10h		;point to System page correspond to 0x0
	out (MMUptr),a
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
wrEntry:
	call CFPage
	xor a
	out (CF1623),a	;msb track is 0
	ld a,0e0h		;set Logical Address mode
	out (CF2427),a
	ld c,CFdata	;point to CF data register
	ld hl,0h		;point to 4K MMU window into memory
moreWsect:
	ld a,(WRtrack)	;get target track
	out (CF815),a
	ld a,(WRsector)	;get target sector
	out (CF07),a	
	ld a,1		
	out (CFsectcnt),a	;write 1 sector

	ld a,30h		;write command
	out (CFstat),a
	call chkdrq
	ld b,0		;sector has 512 8-bit data
	otir
	otir
;wait for write to finish
readbsy2a:
	in a,(CFstat)	;read CF status
	and 80h		;mask off all except busy bit
	jr nz,readbsy2a

	ld a,(WRsector)	;increment target sector
          inc a
	ld (WRsector),a
	jr nz,wrCF_L1
	ld a,(WRtrack)	;overflow to track
	inc a
	ld (WRtrack),a
wrCF_L1:
	ld a,010h		;reaching end of the 4K buffer at 0x0xxx?
	cp h
	jr nz,moreWsect

;end of 4K window, point the window to next 4K in RAM until top of RAM is reached
	ld a,(RAM4K)
	inc a
	ld (RAM4K),a
	cp 40h
	jr z,wrCF9	;CF write done
	ld h,0
;shift hl register left 4 bits
	rla
	rl h
	rla
	rl h
	rla
	rl h
	rla
	rl h
	and 0f0h
	or 0ah		;concatenate 0xa to HL register
	ld l,a
	jp more4K

wrCF9:
;restore logical 0x0 to physical 0x0
	call MMUPage
	ld hl,0ah
	ld a,0h		;point to User page correspond to 0xa000
	out (MMUptr),a
	ld c,MMUsel
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	ld a,1ah		;point to System page correspond to 0xa000
	out (MMUptr),a
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	call UARTPage
	jp CMD

;	org 0b350h
;use 0x0 as 4K window to copy data from CF to 512K RAM
;ROMWBW is stored starting from track 1 sector 0x20
;after copy is completed, jump to 0x0
btROMWBW:
	ld a,020h		;initialize source sector
	ld (RDsector),a
	ld a,1		;initialize source track
	ld (RDtrack),a
	xor a
	ld (RAM4K),a
	ld hl,0ah		;start with lowest 4K of 512K RAM
	jr btEntry
moreR4K
	call MMUPage
	xor a		;point to User page correspond to 0x6000
	out (MMUptr),a
	ld c,MMUsel
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	ld a,10h		;point to System page correspond to 0x6000
	out (MMUptr),a
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
btEntry:
	call CFPage
	xor a
	out (CF1623),a	;msb track is 0
	ld a,0e0h		;set Logical Address mode
	out (CF2427),a
	ld c,CFdata	;point to CF data register
	ld hl,0h		;point to 4K MMU window into memory
moreRsect:
	ld a,(RDtrack)	;get source track
	out (CF815),a
	ld a,(RDsector)	;get source sector
	out (CF07),a	
	ld a,1		
	out (CFsectcnt),a	;read 1 sector

	ld a,20h		;read command
	out (CFstat),a
	call chkdrq
	ld b,0		;sector has 512 8-bit data
	inir
	inir

	ld a,(RDsector)	;increment source sector
          inc a
	ld (RDsector),a
	jr nz,rdCF_L1
	ld a,(RDtrack)	;overflow to track
	inc a
	ld (RDtrack),a
rdCF_L1:
	ld a,010h		;reaching end of the 4K buffer at 0x0?
	cp h
	jr nz,moreRsect
	jr getRAM4K

;end of 4K window, point the window to next 4K in RAM until top of RAM is reached
getRAM4K:
	ld a,(RAM4K)
	inc a
	ld (RAM4K),a
	cp 40h
	jr z,rdCF9	;CF read done
	ld h,0
;shift hl register left 4 bits
	rla
	rl h
	rla
	rl h
	rla
	rl h
	rla
	rl h
	and 0f0h
	or 0ah		;concatenate 0xa to HL register
	ld l,a
	jp moreR4K

rdCF9:
;restore logical 0x0 to physical 0x0
	call MMUPage
	ld hl,0ah
	xor a		;point to User page correspond to 0xa000
	out (MMUptr),a
	ld c,MMUsel
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	ld a,10h		;point to System page correspond to 0xa000
	out (MMUptr),a
	db 0edh,0bfh	;op code for OUTW (C),HL
;	outw (c),hl
	
	call ZeroPage
	jp 0


	END


