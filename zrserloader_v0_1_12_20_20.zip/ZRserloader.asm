;12/15/20 Adopted from ZRCC serial loader
; Autostart from 0xB400 after the 2nd file is loaded
; file load program fit in 256 bytes
; File is intel HEX format
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; ZZRCC Loader, Copyright (C) 2020 Hui-chien Shen
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

UARTconf 	equ 10h		; UART configuration register
RxData  	equ 16h        	; on-chip UART receive register
TxData  	equ 18h        	; on-chip UART transmit register
RxStat  	equ 14h        	; on-chip UART transmitter status/control register
TxStat  	equ 12h        	; 0n-chip UART receiver status/control register
Refresh 	equ 0E8h		; refresh register

	
	org 0		; this is the starting address of serial loaded program
          LD SP,0FFFFH  ; initialize stack pointer to top of memory
          LD C,08H		; C points to I/O page address
   	LD L,0FEH		; write 0xFE to I/O page
	db 0EDh,6Eh	; this is the op code for LDCTL (C),HL
;UART is already configured to 115200 odd parity
	ld a,80h
	out (TxStat),a	;enable UART transmit
	ld hl,SignOn$	; print the sign on message
	call strout
TxDone:			;wait for transmit done before change parameter
	in a,(TxStat)	;chk transmit empty?
	rrca		;transmit empty is bit 1
	jr nc,TxDone
	ld a,0c2h		;change to no parity
	out (UARTconf),a
main:
	call cinq
	cp ':'			; intel load file starts with :
	jr nz,main
fileload:
	call GETHEX	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a			; save byte count to reg D
	ld b,a			; initialize the checksum
	call GETHEX	; get MSB of address
	ld h,a			; HL points to memory to be loaded
	add a,b			; accumulating checksum
	ld b,a			; checksum is kept in reg B
	call GETHEX	; get LSB of address
	ld l,a
	add a,b			; accumulating checksum
	ld b,a			; checksum is kept in reg B
	call GETHEX	; get the record type, 0 is data, 1 is end
	cp 0
	jr z,filesave
	cp 1				; end of file transfer?
	jr nz,unknown	; if not, print a 'U'
; end of the file load
	call GETHEX	; flush the line, get the last byte
	ld hl,X$		;mark the end with'X'
	call strout
	jp 0b400h		;assume the loaded file start from 0xB400

; the assumption is the data is good and will be saved to the destination memory
filesave:
	add a,b			; accumulating checksum of record type
	ld b,a			; checksum is kept in reg B
filesav1:
	call GETHEX	; get a byte
	ld (hl),a		; save to destination
	add a,b			; accumulating checksum
	ld b,a			; checksum is kept in reg B
	inc hl
	dec d
	jr nz,filesav1
	call GETHEX	; get the checksum
	neg a			; 2's complement
	cp b				; compare to checksum accumulated in reg B
	jr nz,badload	; checksum not match, put '?'
	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr main			; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
	jr main

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GETHEX -- Get byte from console as hex

GETHEX:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ASCHEX -- Convert ASCII coded hex to nybble
;
;pre: A register contains ASCII coded nybble
;post: A register contains nybble
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ASCHEX: 	SUB 30h
        	CP 0Ah
        	RET M
        	AND 5Fh
        	SUB 07h
        	RET
; string output
; output string pointed by HL until null terminator
strout:
	ld a,(hl)		;get next character
	or a		;null terminator?
	ret z		;return if null terminator
	call cout		; put out a character
	inc hl		; next char in the string
	jr strout
; output char in reg A
cout:
	push af
cout1:
	in a,(TxStat)	;chk transmit empty?
	rrca		;transmit empty is bit 1
	jr nc,cout1
	pop af
	out (TxData),a	;write out data
	ret

cinq:  
;get character from console without echo back  
	in a,(RxStat)	;read status
	and 10h		;data ready flag is in D[4]
	jr z,cinq
	in a,(RxData)	; read data
	ret
X$	db "X",10,13,0
SignOn$: 	db 0ah,0dh,"ZZRCC Loader v0.1",0ah,0dh
	db "Change serial port to 115200 N81",0ah,0dh
	db "Auto start at 0xB400",0ah,0dh,0

	db 0,0



	db 0	; pad to exactly 255 bytes
	end
