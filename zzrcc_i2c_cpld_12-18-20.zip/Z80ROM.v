module Z80ROM( 
    input [4:0]addr, 
    output reg [7:0]ROMdata); 
    always @(*)
    begin
    //embedded Z80 instruction in ROM
        case(addr)
        5'b00000: ROMdata = 8'h0e; //
        5'b00001: ROMdata = 8'h08; 
        5'b00010: ROMdata = 8'h2e; //
        5'b00011: ROMdata = 8'h00; // 
        5'b00100: ROMdata = 8'hed; //
        5'b00101: ROMdata = 8'h6e; //  
        5'b00110: ROMdata = 8'hdb; // 
        5'b00111: ROMdata = 8'h17; // 
        5'b01000: ROMdata = 8'h17; // 
        5'b01001: ROMdata = 8'h38; // 
        5'b01010: ROMdata = 8'hfb; // 
        5'b01011: ROMdata = 8'h3e; //  
        5'b01100: ROMdata = 8'h20; // 
        5'b01101: ROMdata = 8'hd3; //  
        5'b01110: ROMdata = 8'h17; //  
        5'b01111: ROMdata = 8'hdb; //
        5'b10000: ROMdata = 8'h17; //      
        5'b10001: ROMdata = 8'he6; // 
        5'b10010: ROMdata = 8'h08; //  
        5'b10011: ROMdata = 8'h28; //  
        5'b10100: ROMdata = 8'hfa; //  
        5'b10101: ROMdata = 8'h0e; // 
        5'b10110: ROMdata = 8'h10; // 
        5'b10111: ROMdata = 8'h21; // 
        5'b11000: ROMdata = 8'h80; // 
        5'b11001: ROMdata = 8'hb0; // 
        5'b11010: ROMdata = 8'h45; // 
        5'b11011: ROMdata = 8'hed; // 
        5'b11100: ROMdata = 8'hb2; // 
        5'b11101: ROMdata = 8'hc3; // 
        5'b11110: ROMdata = 8'h80; // 
        5'b11111: ROMdata = 8'hb0; // 
      
        endcase
    end
endmodule